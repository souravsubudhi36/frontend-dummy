import React from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Home from "./pages/Home";
import Hub from "./pages/Hub";
import SideNavbar from "./components/SideNavbar";
import Newtask from "./pages/NewTask";



const App = () => {
  return (
    <div>
      <Router>
        <Switch>
        <Route path="/" exact component={Home} />
        <div>
        <SideNavbar/>
          <Route path= "/hub" exact component={Hub} />
          <Route path= "/newtask" exact component={Newtask} />
        </div>
        
        </Switch>
            
      </Router>


     
    </div>
  );
};

export default App;
